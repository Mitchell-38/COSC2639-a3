import json
import boto3
from io import StringIO

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    s3Client = boto3.client("s3")
    
    table = dynamodb.Table('posts')
    
    response = table.scan()
    data = response['Items']
    
    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        data.extend(response['Items'])
        
    response = response["Items"]
    
    fileData = ""
    
    for x in response:
        fileData += x["user"] + "\n"
    
    # Put the data into a s3 bucket.
    response = s3Client.put_object(
        Body=fileData,
        Bucket="s3858182-a3-emr",
        Key="input/posters.txt")
        
    return response
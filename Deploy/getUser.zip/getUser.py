import json
import boto3

def lambda_handler(event, context):
    client = boto3.client('dynamodb')
    partitionKey = event["email"]
    
    results = client.get_item(
        TableName = "login",
        Key = {
            "email" : {
                "S" : partitionKey
            }
        })
    return results

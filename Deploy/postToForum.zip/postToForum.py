import json
import boto3
from datetime import datetime

def lambda_handler(event, context):
    client = boto3.client('dynamodb')
    user = event["user"]
    title = event["title"]
    content = event["content"]
    imageSet = False
    
    if len(event["image"]) > 0:
        image = event["image"]
        imageSet = True

    time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    postID = user + time
    
    
    if (imageSet):
        results = client.put_item(
            TableName = "posts",
            Item={
                'postID': {
                    'S': postID,
                },
                'user': {
                    'S': user,
                },
                'title': {
                    'S': title,
                },
                'content': {
                    'S': content,
                },
                'image': {
                    'S': image,
                },
                'time': {
                    'S': time
                }
                
            })
    else:
        results = client.put_item(
            TableName = "posts",
            Item={
                'postID': {
                    'S': postID,
                },
                'user': {
                    'S': user,
                },
                'title': {
                    'S': title,
                },
                'content': {
                    'S': content,
                },
                'time': {
                    'S': time
                }
                
            })
        
    return results


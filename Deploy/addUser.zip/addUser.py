import json
import boto3

def lambda_handler(event, context):
    client = boto3.client("dynamodb")
    
    email = event["email"]
    username = event["username"]
    password = event["password"]
    
    results = client.put_item(
        TableName="login",
        Item={
            "email": {
                "S": email
            }, 
            "user_name": {
                "S": username
            },
            "password": {
                "S": password
            }
        })
        
    return results